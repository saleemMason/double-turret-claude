/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;

/** An {@link LedEffect} that reverses the direction of another effect. */
public class ReversedEffect implements LedEffect {
  private final LedEffect effect;

  public ReversedEffect(LedEffect effect) {
    this.effect = effect;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    LedOutputFn fn = effect.process(section);
    return (pos) -> fn.get(1.0 - pos);
  }
}
