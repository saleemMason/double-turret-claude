/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.math;

import edu.wpi.first.math.MathUtil;

/**
 * Stores a range between two values <br>
 * This class will correct input error to ensure that the high endpoint is always greater than or
 * equal to the lower endpoint.
 */
public class Range {
  private final double low;
  private final double high;

  public enum OutsideRange {
    BELOW,
    ABOVE,
    WITHIN_RANGE
  }

  /**
   * Construct with no default arguments.
   *
   * @param low Initial low endpoint
   * @param high Initial high endpoint
   */
  public Range(double low, double high) {
    if (high < low) {
      double temp = high;
      high = low;
      low = temp;
    }

    this.low = low;
    this.high = high;
  }

  /** Convert to string containing the Range endpoints in the form '[low, high]' */
  @Override
  public String toString() {
    return "[" + low + ", " + high + "]";
  }

  /**
   * Simple accessor for the high endpoint
   *
   * @return high endpoint
   */
  public double getHigh() {
    return high;
  }

  /**
   * Simple accessor for the low endpoint
   *
   * @return low endpoint
   */
  public double getLow() {
    return low;
  }

  /**
   * Determines range between high and low endpoints
   *
   * @return distance between endpoints
   */
  public double getWidth() {
    return high - low;
  }

  /**
   * Finds the center value between the high and low endpoints
   *
   * @return the center between endpoints
   */
  public double getCenter() {
    return (high + low) / 2.0;
  }

  /**
   * Clamp this range to fit fully within another range.
   *
   * @param range Range to clamp to.
   */
  public Range clampTo(Range range) {
    return clampTo(range.getLow(), range.getHigh());
  }

  /**
   * Clamp this range to fit fully within another range.
   *
   * @param low New low value to clamp to.
   * @param high New high value to clamp to.
   */
  public Range clampTo(double low, double high) {
    double newLow = Math.max(this.low, low);
    double newHigh = Math.min(this.high, high);

    return new Range(newLow, newHigh);
  }

  /**
   * Determines if a given value is within a range of two values, including the values themselves.
   *
   * @param value value compared with the two bounds
   * @return boolean whether the value is within the two bounds
   */
  public boolean inRange(double value) {
    return value >= low && value <= high;
  }

  /**
   * Determines if a given value is outside a range of two values, excluding the values themselves.
   * Returns {@link OutsideRange#BELOW} if the given value is less than the lower value of the
   * range, and {@link OutsideRange#ABOVE} if its greater than the higher value of the range.
   * Returns {@link OutsideRange#WITHIN_RANGE} if the given value is within the range.
   *
   * @param value value compared with the two bounds
   * @return a {@link OutsideRange} based on the how the given value compares to the range
   */
  public OutsideRange outOfRange(double value) {
    if (value < low) {
      return OutsideRange.BELOW;
    } else if (value > high) {
      return OutsideRange.ABOVE;
    } else {
      return OutsideRange.WITHIN_RANGE;
    }
  }

  /**
   * Forces a value to be within a range of two values
   *
   * @param value value compared with the two bounds
   * @return the minimum or maximum bound if the value is passed them, and the value if it is
   *     between them
   */
  public double clamp(double value) {
    return MathUtil.clamp(value, low, high);
  }

  /**
   * Applies a linear interpolation between the min and max values based on the given {@code m}
   * value. If an {@code m} value is provided beyond {@code 0.0 - 1.0}, the output value will be
   * coerced to stay within the min and max values of the range. {@code m} must be finite.
   *
   * @see Range#extrapolate(double)
   * @see Range#inverseInterpolate(double)
   * @param m
   *     <ul>
   *       <li>{@code m = 0.0} - The min value of the range is returned.
   *       <li>{@code m = 1.0} - The max value of the range is returned.
   *       <li>{@code 0.0 < m < 1.0} - A linearly interpolated value between min and max is
   *           returned.
   *     </ul>
   *
   * @return the interpolated value based on {@code m}.
   */
  public double interpolate(double m) {
    return clamp(extrapolate(m));
  }

  /**
   * Applies a linear interpolation between the min and max values based on the given {@code m}
   * value. If an {@code m} value is provided beyond {@code 0.0 - 1.0}, the same linear
   * interpolation is applied to extrapolate the output value. {@code m} must be finite.
   *
   * @see Range#interpolate(double)
   * @see Range#inverseExtrapolate(double)
   * @param m
   *     <ul>
   *       <li>{@code m = 0.0} - The min value of the range is returned.
   *       <li>{@code m = 1.0} - The max value of the range is returned.
   *       <li>{@code 0.0 < m < 1.0} - A linearly interpolated value between min and max is
   *           returned.
   *       <li>{@code m < 0.0 or m > 1.0} - The same linear equation is applied beyond the range,
   *           extrapolating the output value.
   *     </ul>
   *
   * @return the interpolated/extrapolated value based on {@code m}.
   */
  public double extrapolate(double m) {
    // Checking for an exact value of 0.0 or 1.0 is required to handle a range with one finite limit
    // and one infinite limit.
    if (m == 0.0) {
      return low;
    }
    if (m == 1.0) {
      return high;
    }
    return high * m + low * (1.0 - m);
  }

  /**
   * Given an input value, this function will return a value that represents the linearly
   * interpolated position of the input value within the {@link Range} as a normalized number. The
   * returned normalized number will also be coerced within {@code 0.0 - 1.0}.
   *
   * @see Range#interpolate(double)
   * @see Range#inverseExtrapolate(double)
   * @param value the value to be compared to this {@link Range}
   * @return
   *     <ul>
   *       <li>{@code 0.0} - The given value is equal to the min value of the range
   *       <li>{@code 1.0} - The given value is equal to the max value of the range
   *       <li>{@code > 0.0 and < 1.0} - A normalized value that represents the linearly
   *           interpolated position of the input value within the {@link Range}
   *     </ul>
   */
  public double inverseInterpolate(double value) {
    return inverseExtrapolate(clamp(value));
  }

  /**
   * Given an input value, this function will return a value that represents the linearly
   * interpolated position of the input value within (and outside of) the {@link Range} as a
   * normalized number.
   *
   * @see Range#extrapolate(double)
   * @see Range#inverseInterpolate(double)
   * @param value the value to be compared to this {@link Range}
   * @return
   *     <ul>
   *       <li>{@code 0.0} - The given value is equal to the min value of the range
   *       <li>{@code 1.0} - The given value is equal to the max value of the range
   *       <li>{@code > 0.0 and < 1.0} - A normalized value that represents the linearly
   *           interpolated position of the input value within the {@link Range}
   *       <li>{@code < 0.0} - A normalized value that represents the linearly interpolated position
   *           of the input value outside and below the {@link Range}
   *       <li>{@code > 1.0} - A normalized value that represents the linearly interpolated position
   *           of the input value outside and above the {@link Range}
   *     </ul>
   */
  public double inverseExtrapolate(double value) {
    if (value == low) {
      return 0.0;
    }
    if (value == high) {
      return 1.0;
    }

    if (Double.isFinite(low)) {
      return (value - low) / getWidth();
    } else {
      return 1.0 - (high - value) / getWidth();
    }
  }

  /**
   * The given input value will be linearly remapped based off of the current {@link Range} to the
   * provided {@code otherRange}. {@code in} must be finite.
   *
   * @see <a href="https://docs.arduino.cc/language-reference/en/functions/math/map/">Arduino's
   *     map()</a> for another explanation
   * @param in the value to remap
   * @param otherRange the other range to remap the given value to
   * @param extrapolate whether or not the remap should extrapolate if its outside of the current
   *     {@link Range}
   * @return the value remapped to the {@code otherRange}
   */
  public double remap(double in, Range otherRange, boolean extrapolate) {
    if (extrapolate) {
      return otherRange.extrapolate(inverseExtrapolate(in));
    } else {
      return otherRange.interpolate(inverseInterpolate(in));
    }
  }
}
