package frc.robot.util.robotidentifter;

import java.util.Map;
import org.littletonrobotics.junction.AutoLog;

public interface RobotIdentifierIO<R extends RobotIdentification> {
  @AutoLog
  public static class RobotIdentifierIOInputs {
    String macAddress;
    String identifierName;
  }

  public default void updateInputs(
      RobotIdentifierIOInputs inputs, Map<String, String> macAddressToNameMap) {}
}
