/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedColor;
import frc.robot.util.leds.LedEffect.SimpleLedEffect;

/** Creates a simple color gradient effect. */
public class GradientEffect implements SimpleLedEffect {
  private final LedColor startColor;
  private final LedColor endColor;

  /**
   * A two color gradient effect that starts with the provided start {@link LedColor} and ends with
   * the provided end {@link LedColor}.
   *
   * @param startColor the {@link LedColor} to start the gradient with
   * @param endColor the {@link LedColor} to end the gradient with
   */
  public GradientEffect(LedColor startColor, LedColor endColor) {
    this.startColor = startColor;
    this.endColor = endColor;
  }

  /**
   * A monochromatic gradient effect that starts {@link LedColor#black} and ends with the provided
   * end {@link LedColor}.
   *
   * @param endColor the {@link LedColor} to end the gradient with
   */
  public GradientEffect(LedColor endColor) {
    this.startColor = LedColor.black;
    this.endColor = endColor;
  }

  @Override
  public LedColor get(double position) {
    return endColor.adjustSaturation(position).add(startColor.adjustSaturation(1.0 - position));
  }
}
