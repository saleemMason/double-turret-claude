package frc.robot.util.pid;

import com.ctre.phoenix6.configs.Slot0Configs;
import com.ctre.phoenix6.configs.Slot1Configs;
import com.ctre.phoenix6.configs.Slot2Configs;
import com.ctre.phoenix6.signals.GravityTypeValue;
import com.revrobotics.spark.ClosedLoopSlot;
import com.revrobotics.spark.config.ClosedLoopConfig;

public class ClosedLoopConstants extends PidConstants {
  public enum GravityFeedforwardType {
    ELEVATOR_STATIC,
    ARM_COSINE,
  }

  protected double kS;
  protected double kG;
  protected GravityFeedforwardType gravityType = GravityFeedforwardType.ELEVATOR_STATIC;
  protected double kV;
  protected double kA;

  public double getKS() {
    return kS;
  }

  public ClosedLoopConstants withKS(double kS) {
    this.kS = kS;
    return this;
  }

  public double getKG() {
    return kG;
  }

  public ClosedLoopConstants withKG(double kG) {
    this.kG = kG;
    return this;
  }

  public GravityFeedforwardType getGravityType() {
    return gravityType;
  }

  public ClosedLoopConstants withGravityType(GravityFeedforwardType gravityType) {
    this.gravityType = gravityType;
    return this;
  }

  public double getKV() {
    return kV;
  }

  public ClosedLoopConstants withKV(double kV) {
    this.kV = kV;
    return this;
  }

  public double getKA() {
    return kA;
  }

  public ClosedLoopConstants withKA(double kA) {
    this.kA = kA;
    return this;
  }

  @Override
  public ClosedLoopConstants withKP(double kP) {
    super.withKP(kP);
    return this;
  }

  @Override
  public ClosedLoopConstants withKD(double kD) {
    super.withKD(kD);
    return this;
  }

  private GravityTypeValue getTalonGravityType() {
    return switch (gravityType) {
      case ELEVATOR_STATIC -> GravityTypeValue.Elevator_Static;
      case ARM_COSINE -> GravityTypeValue.Arm_Cosine;
      default -> GravityTypeValue.Elevator_Static;
    };
  }

  @Override
  public Slot0Configs getTalonSlot0() {
    return super.getTalonSlot0()
        .withKS(kS)
        .withKG(kG)
        .withGravityType(getTalonGravityType())
        .withKV(kV)
        .withKA(kA);
  }

  @Override
  public Slot1Configs getTalonSlot1() {
    return super.getTalonSlot1()
        .withKS(kS)
        .withKG(kG)
        .withGravityType(getTalonGravityType())
        .withKV(kV)
        .withKA(kA);
  }

  @Override
  public Slot2Configs getTalonSlot2() {
    return super.getTalonSlot2()
        .withKS(kS)
        .withKG(kG)
        .withGravityType(getTalonGravityType())
        .withKV(kV)
        .withKA(kA);
  }

  @Override
  public ClosedLoopConfig getSparkConfig() {
    return getSparkConfig(ClosedLoopSlot.kSlot0);
  }

  @Override
  public ClosedLoopConfig getSparkConfig(ClosedLoopSlot slot) {
    ClosedLoopConfig config = super.getSparkConfig(slot);
    config.feedForward.sva(kS, kV, kA, slot);

    switch (gravityType) {
      case ELEVATOR_STATIC -> config.feedForward.kG(kG);

      case ARM_COSINE -> config.feedForward.kCos(kG);
    }

    return config;
  }
}
