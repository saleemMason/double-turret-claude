/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds;

import frc.robot.util.leds.effects.ReversedEffect;
import frc.robot.util.leds.effects.SolidColorEffect;

/**
 * A color based effect meant to be displayed on a LED strip. For instance, a {@link
 * SolidColorEffect} where all LEDs under the control of the {@link SolidColorEffect} are commanded
 * to display the same singular color.
 */
public interface LedEffect {
  /**
   * The result of processing an {@link LedEffect}. This is most often returned as a lambda since it
   * allows for easy reuse of calculations done in the {@link LedEffect#process()} function.
   */
  @FunctionalInterface
  public interface LedOutputFn {
    /**
     * Converts a singular normalized LED position into the {@link LedColor} the effect should
     * produce at that position.
     *
     * @param position A normalized position [0.0, 1.0] of a singular LED
     * @return The color the effect produces at the provided position
     */
    LedColor get(double position);
  }

  /**
   * A simplified {@link LedEffect} where the color can be determined without knowledge of the
   * {@link LedSection} and without deferring to other effects.
   *
   * <p>This is meant to simplify the creation of effects that don't need to use any pre-processing
   * or layered effects.
   */
  public interface SimpleLedEffect extends LedEffect {
    /**
     * Converts a singular normalized LED position into the {@link LedColor} the effect should
     * produce at that position.
     *
     * @param position A normalized position [0.0, 1.0] of a singular LED
     * @return The color the effect produces at the provided position
     */
    public LedColor get(double position);

    @Override
    public default LedOutputFn process(LedSection section) {
      return this::get;
    }
  }

  /**
   * Process all common data needed to setup the effect, then return an {@link LedOutputFn} mapping
   * LED position to LED color. This function will be called once for every use of this effect,
   * including multiple uses on the same {@link LedSection}.
   *
   * @param section the {@link LedSection} to display the results of the returned {@link
   *     LedOutputFn} on
   * @return An {@link LedOutputFn} for this effect at the current time.
   */
  LedOutputFn process(LedSection section);

  /**
   * Gives you a reversed version of the current {@link LedEffect}.
   *
   * @return the current {@link LedEffect}, but the effect is applied in reverse.
   */
  default LedEffect reversed() {
    return new ReversedEffect(this);
  }
}
