package frc.robot.util.math;

import edu.wpi.first.math.MathUtil;
import edu.wpi.first.math.geometry.Translation2d;

public class GeometryUtil {
  public static record ClosestPoint(Translation2d point, double distance, Translation2d normal) {
    /**
     * Make a new ClosestPoint from the reference point and the calculated closestPoint.
     *
     * @param point
     * @param closestPoint
     */
    private static ClosestPoint fromPoints(Translation2d point, Translation2d closestPoint) {
      Translation2d normalVector = closestPoint.minus(point);
      normalVector.div(normalVector.getNorm());

      return new ClosestPoint(point, point.getDistance(closestPoint), normalVector);
    }

    /**
     * Get the {@link ClosestPoint} with the smallest distance value
     *
     * @param a a point
     * @param b another point
     * @return The point with the smallest distance value
     */
    public static ClosestPoint min(ClosestPoint a, ClosestPoint b) {
      if (b.distance < a.distance) {
        return b;
      }

      return a;
    }

    /**
     * General function for finding the closest point between a point and segment.
     *
     * @param p The point P
     * @param a The start point of segment AB
     * @param b The end point of segment AB
     * @param clampToSegmentEnds If true, treat AB as a segment and clamp to it's ends, otherwise
     *     return the distance to the closest point on the infinite line AB
     * @param returnPointOnLine Return P as the {@code point} of the ClosestPoint instead of the
     *     segment on AB
     * @return closest point between P and AB
     */
    private static ClosestPoint generalPointToLine(
        Translation2d p,
        Translation2d a,
        Translation2d b,
        boolean clampToSegmentEnds,
        boolean returnPointOnLine) {
      Translation2d ab = b.minus(a);

      // Linear interpolation value on line AB for the closest point to P.
      // 0 is point A, 1 is point B. This is relative to point A, but extends
      // to the whole line, so clamp to the endpoints of segment AB
      double t = ab.dot(p.minus(a)) / ab.getSquaredNorm();
      if (clampToSegmentEnds) {
        t = MathUtil.clamp(t, 0, 1);
      }

      Translation2d closestPoint = a.plus(ab.times(t));

      if (returnPointOnLine) {
        return ClosestPoint.fromPoints(closestPoint, p);
      } else {
        return ClosestPoint.fromPoints(p, closestPoint);
      }
    }

    /**
     * Get the point on segment AB that is closest to point P.
     *
     * @param a The start point of segment AB
     * @param b The end point of segment AB
     * @param p The point P
     * @return ClosestPoint on segment AB
     */
    public static ClosestPoint segmentToPoint(Translation2d a, Translation2d b, Translation2d p) {
      return generalPointToLine(p, a, b, true, true);
    }

    /**
     * Get the point on the infinite line AB that is closest to point P.
     *
     * @param a The start point of line AB
     * @param b The end point of line AB
     * @param p The point P
     * @return ClosestPoint on line AB
     */
    public static ClosestPoint segmentToLine(Translation2d a, Translation2d b, Translation2d p) {
      return generalPointToLine(p, a, b, false, true);
    }

    /**
     * Returns the point P as a {@link ClosestPoint} to segment AB. The point will be the same as P,
     * but the distance will be the closest distance from P to AB
     *
     * @param p The point P
     * @param a The start point of segment AB
     * @param b The end point of segment AB
     * @return ClosestPoint P using segment AB as reference
     */
    public static ClosestPoint pointToSegment(Translation2d p, Translation2d a, Translation2d b) {
      return generalPointToLine(p, a, b, true, false);
    }

    /**
     * Returns the point P as a {@link ClosestPoint} to line AB. The point will be the same as P,
     * but the distance will be the closest distance from P to AB
     *
     * @param p The point P
     * @param a The start point of line AB
     * @param b The end point of line AB
     * @return ClosestPoint P using line AB as reference
     */
    public static ClosestPoint pointToLine(Translation2d p, Translation2d a, Translation2d b) {
      return generalPointToLine(p, a, b, false, false);
    }

    /**
     * Idk what this does but it helps check for segment intersection
     * https://github.com/vlecomte/cp-geo/blob/master/basics/segment.tex
     */
    public static final double lineIntersectionOrientFunction(
        Translation2d a, Translation2d b, Translation2d c) {
      return (b.minus(a)).cross(c.minus(a));
    }

    /**
     * Get the point on segment AB to closest to segment CD. The {@link ClosestPoint} returned will
     * lie on segment AB
     *
     * @param a The start point of segment AB
     * @param b The end point of segment AB
     * @param c The start point of segment CD
     * @param d The end point of segment CD
     * @return Shortest distance from segment AB to segment CD
     */
    public static ClosestPoint segmentToSegment(
        Translation2d a, Translation2d b, Translation2d c, Translation2d d) {
      // Simple line segment intersection test
      // https://github.com/vlecomte/cp-geo/blob/master/basics/segment.tex
      double oa = lineIntersectionOrientFunction(c, d, a),
          ob = lineIntersectionOrientFunction(c, d, b),
          oc = lineIntersectionOrientFunction(a, b, c),
          od = lineIntersectionOrientFunction(a, b, d);
      if (oa * ob < 0 && oc * od < 0) {
        Translation2d intersectionPoint = ((a.times(ob)).minus(b.times(oa))).div(ob - oa);
        return ClosestPoint.fromPoints(intersectionPoint, intersectionPoint);
      }

      // Use endpoint of AB as reference
      ClosestPoint p1 = pointToSegment(a, c, d);
      ClosestPoint p2 = pointToSegment(b, c, d);

      // Use point on AB as reference
      ClosestPoint p3 = segmentToPoint(a, b, c);
      ClosestPoint p4 = segmentToPoint(a, b, d);

      // This point is the closest, however it will not have the correct distance value if the lines
      // intersect
      ClosestPoint closestPoint =
          ClosestPoint.min(ClosestPoint.min(p1, p2), ClosestPoint.min(p3, p4));

      return pointToSegment(closestPoint.point, c, d);
    }
  }
}
