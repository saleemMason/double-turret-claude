/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import static edu.wpi.first.units.Units.Seconds;

import edu.wpi.first.units.measure.Frequency;
import edu.wpi.first.units.measure.Time;
import edu.wpi.first.wpilibj.Timer;
import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;
import frc.robot.util.math.UnitUtil;

/**
 * A simple bistable blink effect that will switch between an "off" {@link LedEffect} and an "on"
 * {@link LedEffect} based on an internal timer.
 */
public class BlinkEffect implements LedEffect {
  private final Timer timer;
  private final Time blinkInterval;
  private Time pulseWidth = Seconds.zero();

  private final LedEffect onEffect;
  private final LedEffect offEffect;

  /**
   * Creates a {@link BlinkEffect} that will switch between an {@code onEffect} and an {@code
   * onEffect} based on the given PRI (Pulse Repetition Interval) and the provided timer.
   *
   * <p>The duty cycle of the "off/on" pattern within a single cycle defaults to 1/2 the cycle. To
   * adjust the duty cycle or the pulse width, use {@link BlinkEffect#withPulseWidth(Time)} or
   * {@link BlinkEffect#withDutyCycle(double)}.
   *
   * @param onEffect the {@link LedEffect} applied when in the "on" state
   * @param offEffect the {@link LedEffect} applied when in the "off" state
   * @param blinkInterval the time it takes to complete one full cycle (on-off) of the blinking
   *     animation before it loops
   * @param timer the timer used to time the blink animation
   */
  private BlinkEffect(LedEffect offEffect, LedEffect onEffect, Time blinkInterval, Timer timer) {
    this.offEffect = offEffect;
    this.onEffect = onEffect;

    this.blinkInterval = blinkInterval;
    this.pulseWidth = blinkInterval.times(0.5);

    this.timer = timer;
    this.timer.start();
  }

  /**
   * Creates a {@link BlinkEffect} that will switch between an {@code offEffect} and an {@code
   * onEffect} based on the given PRI (Pulse Repetition Interval).
   *
   * <p>The duty cycle of the "off/on" pattern within a single cycle defaults to 1/2 the cycle. To
   * adjust the duty cycle or the pulse width, use {@link BlinkEffect#withPulseWidth(Time)} or
   * {@link BlinkEffect#withDutyCycle(double)}.
   *
   * @param onEffect the {@link LedEffect} applied when in the "on" state
   * @param offEffect the {@link LedEffect} applied when in the "off" state
   * @param blinkInterval the time it takes to complete one full cycle (on-off) of the blinking
   *     animation before it loops cycle
   */
  public BlinkEffect(LedEffect onEffect, LedEffect offEffect, Time blinkInterval) {
    this(onEffect, offEffect, blinkInterval, new Timer());
  }

  /**
   * Creates a {@link BlinkEffect} that will switch between turning the LEDs completely off and an
   * {@code onEffect} based on the given PRI (Pulse Repetition Interval).
   *
   * <p>The duty cycle of the "off/on" pattern within a single cycle defaults to 1/2 the cycle. To
   * adjust the duty cycle or the pulse width, use {@link BlinkEffect#withPulseWidth(Time)} or
   * {@link BlinkEffect#withDutyCycle(double)}.
   *
   * @param effect the {@link LedEffect} applied when in the "on" state
   * @param blinkPri the time it takes to complete one full cycle (on-off) of the blinking animation
   *     before it loops
   */
  public BlinkEffect(LedEffect effect, Time blinkPri) {
    this(effect, SolidColorEffect.off(), blinkPri);
  }

  /**
   * Creates a {@link BlinkEffect} that will switch between an {@code offEffect} and an {@code
   * onEffect} based on the given PRF (Pulse Repetition Frequency).
   *
   * <p>The duty cycle of the "off/on" pattern within a single cycle defaults to 1/2 the cycle. To
   * adjust the duty cycle or the pulse width, use {@link BlinkEffect#withPulseWidth(Time)} or
   * {@link BlinkEffect#withDutyCycle(double)}.
   *
   * @param offEffect the {@link LedEffect} applied when in the "off" state
   * @param onEffect the {@link LedEffect} applied when in the "on" state
   * @param blinkFrequency the frequency of the blink animation, or how many times it will complete
   *     one full cycle (on-off) per second
   */
  public BlinkEffect(LedEffect onEffect, LedEffect offEffect, Frequency blinkFrequency) {
    this(onEffect, offEffect, blinkFrequency.asPeriod());
  }

  /**
   * Creates a {@link BlinkEffect} that will switch between turning the LEDs completely off and an
   * {@code onEffect} based on the given PRF (Pulse Repetition Frequency).
   *
   * <p>The duty cycle of the "off/on" pattern within a single cycle defaults to 1/2 the cycle. To
   * adjust the duty cycle or the pulse width, use {@link BlinkEffect#withPulseWidth(Time)} or
   * {@link BlinkEffect#withDutyCycle(double)}.
   *
   * @param effect the {@link LedEffect} applied when in the "on" state
   * @param blinkFrequency the frequency of the blink animation, or how many times it will complete
   *     one full cycle (on-off) per second
   */
  public BlinkEffect(LedEffect effect, Frequency blinkFrequency) {
    this(effect, blinkFrequency.asPeriod());
  }

  /**
   * Changes the pulse width of "off/on" pattern within a single cycle, needs to be a value between
   * zero and the PRI (Pulse Repetition Interval). The actual pulse width that is stored will be
   * coerced to stay within a single cycle period.
   *
   * @param pulseWidth the pulse width of "off/on" pattern within a single cycle. The actual pulse
   *     width that is stored will be coerced to stay within a single cycle period
   * @return this {@link BlinkEffect} after modifying the internal pulse width
   */
  public BlinkEffect withPulseWidth(Time pulseWidth) {
    this.pulseWidth = UnitUtil.clamp(pulseWidth, Seconds.zero(), blinkInterval);
    return this;
  }

  /**
   * Changes the duty cycle of "off/on" pattern within a single cycle, needs to be a value between
   * 0.0 and 1.0. The actual duty cycle that is used will be coerced between 0.0 and 1.0.
   *
   * @param dutyCycle the duty cycle of "off/on" pattern within a single cycle. The actual duty
   *     cycle that is used will be coerced between 0.0 and 1.0 [0.0, 1.0]
   * @return this {@link BlinkEffect} after applying the provided duty cycle
   */
  public BlinkEffect withDutyCycle(double dutyCycle) {
    return withPulseWidth(blinkInterval.times(dutyCycle));
  }

  @Override
  public LedOutputFn process(LedSection section) {
    if (timer.hasElapsed(blinkInterval)) {
      timer.reset();
    }

    if (timer.hasElapsed(pulseWidth)) {
      return offEffect.process(section);
    } else {
      return onEffect.process(section);
    }
  }

  /**
   * Creates a new {@link BlinkEffect} based on the current {@link BlinkEffect}, but with a
   * different "on" {@link LedEffect}, while still maintaining synchronization between the resulting
   * {@link BlinkEffect}s.
   *
   * @param effect the new "on" {@link LedEffect} to use
   * @return a new {@link BlinkEffect} using the new "on" {@link LedEffect} provided
   */
  public BlinkEffect withOnEffect(LedEffect effect) {
    return new BlinkEffect(offEffect, effect, blinkInterval, timer);
  }

  /**
   * Creates a new {@link BlinkEffect} based on the current {@link BlinkEffect}, but with a
   * different "off" {@link LedEffect}, while still maintaining synchronization between the
   * resulting {@link BlinkEffect}s.
   *
   * @param effect the new "off" {@link LedEffect} to use
   * @return a new {@link BlinkEffect} using the new "off" {@link LedEffect} provided
   */
  public BlinkEffect withOffEffect(LedEffect effect) {
    return new BlinkEffect(effect, onEffect, blinkInterval, timer);
  }

  /**
   * Creates a new {@link BlinkEffect} after flipping the "off" and "on" {@link LedEffect}s, while
   * still maintaining synchronization between the resulting {@link BlinkEffect}s.
   *
   * @return a new {@link BlinkEffect} with the opposite behavior of the current {@link BlinkEffect}
   */
  public BlinkEffect opposite() {
    return new BlinkEffect(onEffect, offEffect, blinkInterval, timer);
  }
}
