package frc.robot.util.gradientvalley;

import static edu.wpi.first.units.Units.Meters;
import static edu.wpi.first.units.Units.MetersPerSecond;

import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.units.measure.LinearVelocity;
import frc.robot.util.gradientvalley.GradientValley.GradientFunction;
import frc.robot.util.gradientvalley.GradientValley.GradientFunction1d;

/**
 * A gradent function that slopes toward the closest point on a 2d shape. Evaluates the gradient
 * function with a distance of zero if inside the shape.
 */
public class FlatBottomedShapeGradient implements GradientFunction {
  /** A 2d shape with the capacity to find the closest point. */
  @FunctionalInterface
  public interface FlatBottomedShape {
    /**
     * Get the closest point on the shape to the given position. If the given position is inside the
     * shape, return the given position.
     *
     * @param position The position to get the closest point to.
     * @return The closest point on the shape to the given position.
     */
    public Translation2d getClosestPoint(Translation2d position);
  }

  private final FlatBottomedShape shape;
  private final GradientFunction1d distanceFunction;

  public FlatBottomedShapeGradient(FlatBottomedShape shape, GradientFunction1d distanceFunction) {
    this.shape = shape;
    this.distanceFunction = distanceFunction;
  }

  public static FlatBottomedShapeGradient point(
      Translation2d pointPosition, GradientFunction1d distanceFunction) {
    return new FlatBottomedShapeGradient((_position) -> pointPosition, distanceFunction);
  }

  @Override
  public ChassisSpeeds calculateGradient(Translation2d position) {
    Translation2d closestPoint = shape.getClosestPoint(position);

    LinearVelocity velocity =
        distanceFunction.calculateGradient(Meters.of(position.getDistance(closestPoint)));

    Rotation2d angle = position.minus(closestPoint).getAngle();
    double velocityMetersPerSec = velocity.in(MetersPerSecond);

    return new ChassisSpeeds(
        velocityMetersPerSec * angle.getCos(), velocityMetersPerSec * angle.getSin(), 0.0);
  }
}
