package frc.robot.util.pid;

import static edu.wpi.first.units.Units.RPM;
import static edu.wpi.first.units.Units.RadiansPerSecond;
import static edu.wpi.first.units.Units.RadiansPerSecondPerSecond;
import static edu.wpi.first.units.Units.Second;

import com.ctre.phoenix6.configs.MotionMagicConfigs;
import com.revrobotics.spark.ClosedLoopSlot;
import com.revrobotics.spark.config.MAXMotionConfig;
import edu.wpi.first.math.trajectory.TrapezoidProfile;
import edu.wpi.first.units.measure.AngularAcceleration;
import edu.wpi.first.units.measure.AngularVelocity;

public class MotionProfileConstants {
  AngularVelocity cruiseVelocity = RadiansPerSecond.zero();
  AngularAcceleration maxAcceleration = RadiansPerSecondPerSecond.zero();

  public MotionProfileConstants(
      AngularVelocity cruiseVelocity, AngularAcceleration maxAcceleration) {
    this.cruiseVelocity = cruiseVelocity;
    this.maxAcceleration = maxAcceleration;
  }

  public AngularVelocity getCruiseVelocity() {
    return cruiseVelocity;
  }

  public MotionProfileConstants withCruiseVelocity(AngularVelocity cruiseVelocity) {
    this.cruiseVelocity = cruiseVelocity;
    return this;
  }

  public AngularAcceleration getMaxAcceleration() {
    return maxAcceleration;
  }

  public MotionProfileConstants withMaxAcceleration(AngularAcceleration maxAcceleration) {
    this.maxAcceleration = maxAcceleration;
    return this;
  }

  public MotionMagicConfigs getMotionMagic() {
    return new MotionMagicConfigs()
        .withMotionMagicCruiseVelocity(cruiseVelocity)
        .withMotionMagicAcceleration(maxAcceleration);
  }

  public MAXMotionConfig getMaxMotionConfig() {
    return getMaxMotionConfig(ClosedLoopSlot.kSlot0);
  }

  public MAXMotionConfig getMaxMotionConfig(ClosedLoopSlot slot) {
    return new MAXMotionConfig()
        .cruiseVelocity(cruiseVelocity.in(RPM), slot)
        .maxAcceleration(maxAcceleration.in(RPM.per(Second)), slot);
  }

  public TrapezoidProfile.Constraints getWpilibTrapezoidProfile() {
    return new TrapezoidProfile.Constraints(
        cruiseVelocity.in(RadiansPerSecond), maxAcceleration.in(RadiansPerSecondPerSecond));
  }
}
