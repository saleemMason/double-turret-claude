package frc.robot.util.robotidentifter;

import java.util.Map;

public class RobotIdentifierIOForced<R extends RobotIdentification>
    implements RobotIdentifierIO<R> {
  private final String identifierName;

  public RobotIdentifierIOForced(R forcedRobot) {
    this.identifierName = forcedRobot.name();
  }

  @Override
  public void updateInputs(
      RobotIdentifierIOInputs inputs, Map<String, String> macAddressToNameMap) {
    System.out.println("Robot forced to be: " + identifierName);
    inputs.macAddress = null;
    inputs.identifierName = identifierName;
  }
}
