/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedColor;
import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;
import java.util.function.Supplier;

/**
 * Given a {@link Supplier} of {@link LedColor}, this class will change all LEDs under the control
 * of this effect to the currently provided color by the supplier.
 */
public class ColorSupplierEffect implements LedEffect {
  private final Supplier<LedColor> colorSupplier;

  /**
   * Creates a {@link ColorSupplierEffect} with the given {@link Supplier Supplier} of {@link
   * LedColor} which will be used to update the current color of the LEDs under the control of this
   * effect.
   *
   * @param colorSupplier the {@link Supplier} of {@link LedColor} to be used to update the current
   *     color displayed
   */
  public ColorSupplierEffect(Supplier<LedColor> colorSupplier) {
    this.colorSupplier = colorSupplier;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    var color = colorSupplier.get();
    return (pos) -> color;
  }
}
