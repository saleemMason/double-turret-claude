package frc.robot.util.leds.effects;

import frc.robot.util.leds.LedEffect;
import frc.robot.util.leds.LedSection;

/** An {@link LedEffect} that allows for manually setting the displayed effect. */
public class MutableEffect implements LedEffect {
  private LedEffect currentEffect;

  /**
   * Creates an new {@link MutableEffect}
   *
   * @param initialEffect The initial effect to display
   */
  public MutableEffect(LedEffect initialEffect) {
    currentEffect = initialEffect;
  }

  /** Creates an new {@link MutableEffect} */
  public MutableEffect() {
    this(SolidColorEffect.off());
  }

  public void setCurrentEffect(LedEffect effect) {
    currentEffect = effect;
  }

  @Override
  public LedOutputFn process(LedSection section) {
    return currentEffect.process(section);
  }
}
