package frc.robot.util.gradientvalley;

import edu.wpi.first.math.geometry.Translation2d;
import edu.wpi.first.math.kinematics.ChassisSpeeds;
import edu.wpi.first.units.measure.Distance;
import edu.wpi.first.units.measure.LinearVelocity;
import java.util.List;

/**
 * Maps the robot's position in 2d space into a 2d velocity vector determined by summing a list of
 * gradients. This is often used to draw in the robot to a specified position, like a boulder
 * rolling down a hill or a planet's gravity.
 */
public class GradientValley {
  /**
   * A vector function that takes a position in 2d space and returns the 2d speeds the robot should
   * apply. This function is often defined as the gradient/derivative of some 3d curve, hence the
   * name.
   *
   * <p>Note that this function does not need to strictly be a gradient, nor does it need to be
   * continuous. Any function that maps the entire domain of 2d space into a velocity vector may be
   * used.
   */
  @FunctionalInterface
  public interface GradientFunction {
    /**
     * Calculate the gradient/velocity at the given position
     *
     * @param position The position to calculate the gradient at.
     * @return The gradient vector represented as a {@link ChassisSpeeds}.
     */
    ChassisSpeeds calculateGradient(Translation2d position);
  }

  /**
   * A function that takes a distance in 1d space and returns the 1d speed the robot should apply.
   * This function is often defined as the gradient/derivative of some 3d curve, hence the name.
   *
   * <p>While this interface is not able to be used directly in a {@link GradientValley}, it may be
   * used in some {@link GradientFunction} implementations.
   *
   * <p>Note that this function does not need to strictly be a gradient, nor does it need to be
   * continuous. Any function that maps the entire domain of 2d space into a velocity vector may be
   * used.
   */
  @FunctionalInterface
  public interface GradientFunction1d {
    /**
     * Calculate the gradient/velocity at the given distance to the shape.
     *
     * @param distance The distance to calculate the gradient for.
     * @return The 1d gradient towards the shape.
     */
    public LinearVelocity calculateGradient(Distance distance);
  }

  private final List<GradientFunction> gradientFunctions;

  /**
   * Construct a new GradientValley.
   *
   * @param gradientFunctions The list of gradient functions to use. Note that using too many
   *     gradient functions in a single Valley may incur a performance cost.
   */
  public GradientValley(List<GradientFunction> gradientFunctions) {
    this.gradientFunctions = gradientFunctions;
  }

  /**
   * Calculates the total gradient from all gradient functions at the specified position.
   *
   * @param position The position to calculate the gradient at.
   * @return The gradient velocity vector represented as a {@link ChassisSpeeds}. Will not contain a
   *     rotational component.
   */
  public ChassisSpeeds calculateGradient(Translation2d position) {
    return gradientFunctions.stream()
        .map((f) -> f.calculateGradient(position))
        .reduce(
            new ChassisSpeeds(),
            (totalGradient, individualGradient) -> {
              // Manually add values to avoid allocating many new objects and ensure rotation
              // component is zero
              totalGradient.vxMetersPerSecond += individualGradient.vxMetersPerSecond;
              totalGradient.vyMetersPerSecond += individualGradient.vyMetersPerSecond;
              return totalGradient;
            });
  }
}
