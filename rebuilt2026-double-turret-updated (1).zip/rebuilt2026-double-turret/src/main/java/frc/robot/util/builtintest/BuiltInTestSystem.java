package frc.robot.util.builtintest;

public interface BuiltInTestSystem {
  public String getTestSystemName();
}
