package frc.robot.util.builtintest;

import edu.wpi.first.wpilibj.Alert.AlertType;

public abstract class BuiltInTest {
  public enum Severity {
    STARTUP_INFO,
    STARTUP_WARNING,
    STARTUP_ERROR,

    INFO,
    WARNING,
    ERROR;

    AlertType toAlertType() {
      return switch (this) {
        case INFO, STARTUP_INFO -> AlertType.kInfo;
        case WARNING, STARTUP_WARNING -> AlertType.kWarning;
        case ERROR, STARTUP_ERROR -> AlertType.kError;
      };
    }
  }

  public record TestStatus(boolean pass, String detail) {
    public TestStatus(boolean pass) {
      this(pass, "");
    }
  }

  private final String name;
  private final Severity severity;

  public BuiltInTest(String name, Severity severity) {
    this.name = name;
    this.severity = severity;
  }

  public String getName() {
    return name;
  }

  public Severity getSeverity() {
    return severity;
  }

  public abstract TestStatus getStatus();
}
