/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds.effects;

import edu.wpi.first.wpilibj.DriverStation.Alliance;
import frc.robot.util.AllianceUtil;
import frc.robot.util.leds.LedColor;

public class AllianceEffect extends ConditionalEffect {
  public AllianceEffect() {
    super(
        LedColor.blue.asLedEffect(),
        LedColor.red.asLedEffect(),
        () -> AllianceUtil.getAlliance() == Alliance.Blue);
  }
}
