/* This Source Code Form is subject to the terms of the Mozilla Public
 * License, v. 2.0. If a copy of the MPL was not distributed with this
 * file, You can obtain one at https://mozilla.org/MPL/2.0/. */

package frc.robot.util.leds;

import edu.wpi.first.math.MathUtil;
import frc.robot.util.leds.effects.SolidColorEffect;

/** Represents a color to be displayed on an {@link LedRun}. */
public class LedColor {
  public final double redChannel;
  public final double greenChannel;
  public final double blueChannel;

  public static final LedColor yellow = new LedColor(1.0, 0.9, 0.0);
  public static final LedColor purple = new LedColor(0.6, 0.05, 1.0);
  public static final LedColor cyan = new LedColor(0.0, 1.0, 0.3);
  public static final LedColor red = new LedColor(1.0, 0.0, 0.0);
  public static final LedColor blue = new LedColor(0.0, 0.0, 1.0);
  public static final LedColor green = new LedColor(0.0, 1.0, 0.0);
  public static final LedColor white = new LedColor(1.0, 1.0, 1.0);
  public static final LedColor orange = new LedColor(1.0, 0.67, 0.0);
  public static final LedColor gold = new LedColor(0.937, 0.749, 0.016);
  public static final LedColor black = new LedColor(0.0, 0.0, 0.0);
  /** This is only grey because we use a dark diffuser over our LEDs. */
  public static final LedColor grey = new LedColor(0.05, 0.05, 0.05);

  public static final LedColor off = black;

  static double clampChannel(double value) {
    return MathUtil.clamp(value, 0.0, 1.0);
  }

  /**
   * Generates a new color based on the RGB values provided. Channel values should be normalized to
   * 0.0 to 1.0. Values provided will be internally clamped between 0.0 and 1.0.
   *
   * @param red red channel [0.0, 1.0]
   * @param green green channel [0.0, 1.0]
   * @param blue blue channel [0.0, 1.0]
   */
  public LedColor(double red, double green, double blue) {
    redChannel = clampChannel(red);
    greenChannel = clampChannel(green);
    blueChannel = clampChannel(blue);
  }

  /**
   * Helper function that converts a normalized RGB channel value into an int value from 0 and the
   * provided {@code maxChannelValue}.
   *
   * @param normalized the original normalized channel value to convert
   * @param maxChannelValue the max channel value that is supported by the underlying LED hardware
   *     interface
   * @return the resulting converted value as an int to be used by the underlying LED hardware
   *     interface
   */
  protected static int asInt(double normalized, int maxChannelValue) {
    int rounded = (int) Math.round(normalized * maxChannelValue);
    if (rounded > maxChannelValue) {
      return maxChannelValue;
    } else if (rounded < 0) {
      return 0;
    } else {
      return rounded;
    }
  }

  /**
   * Adjust how saturated the color is and returns it as a new color. A value of 0.0 will result in
   * {@link LedColor#black}. A value of 1.0 will result in the same exact color.
   *
   * @param value how much to adjust the saturation of the current color [0.0, 1.0]
   * @return a new color based on the original color and how much its saturation was adjusted
   */
  public LedColor adjustSaturation(double value) {
    double coerceValue = clampChannel(value);
    return new LedColor(
        redChannel * coerceValue, greenChannel * coerceValue, blueChannel * coerceValue);
  }

  /**
   * Adds two colors together and normalizes the channels.
   *
   * @param otherColor the color color to add to the current color
   * @return a new color based on the two colors being added together
   */
  public LedColor add(LedColor otherColor) {
    var redNew = redChannel + otherColor.redChannel;
    var greenNew = greenChannel + otherColor.greenChannel;
    var blueNew = blueChannel + otherColor.blueChannel;
    var maxChannelValue = Math.max(Math.max(Math.max(redNew, greenNew), blueNew), 1.0);

    return new LedColor(
        redNew / maxChannelValue, greenNew / maxChannelValue, blueNew / maxChannelValue);
  }

  /**
   * Generates a {@link SolidColorEffect} that represents this color, to be used on an {@link
   * LedRun}.
   *
   * @return a {@link SolidColorEffect} that represents this color
   */
  public LedEffect asLedEffect() {
    return new SolidColorEffect(this);
  }
}
