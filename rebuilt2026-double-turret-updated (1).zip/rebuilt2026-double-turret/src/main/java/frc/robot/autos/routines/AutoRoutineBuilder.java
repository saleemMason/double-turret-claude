package frc.robot.autos.routines;

import choreo.auto.AutoRoutine;
import choreo.auto.AutoTrajectory;
import edu.wpi.first.math.geometry.Pose2d;
import edu.wpi.first.math.geometry.Rotation2d;
import edu.wpi.first.math.util.Units;
import edu.wpi.first.wpilibj2.command.Command;
import edu.wpi.first.wpilibj2.command.button.Trigger;
import frc.robot.Robot.Resources;
import frc.robot.Robot.Subsystems;
import frc.robot.autos.AutoManager.AutoInputs;
import frc.robot.autos.AutoManager.AutoParameters;
import frc.robot.commands.AutoDriveCommands;
import frc.robot.generated.choreo.ChoreoTraj;
import java.util.function.Function;

public class AutoRoutineBuilder {
  protected final double poseToleranceMeters = Units.inchesToMeters(5);
  protected final double chainToleranceMeters = Units.inchesToMeters(7.5);
  protected final double chainToleranceRadians = Units.degreesToRadians(20);

  protected final Subsystems s;
  protected final Resources r;
  protected final AutoInputs inputs;

  protected final AutoRoutine routine;
  protected final Trigger routineDone;

  protected AutoRoutineBuilder(AutoRoutine routine, AutoParameters p) {
    s = p.s();
    r = p.r();
    inputs = p.inputs();

    this.routine = routine;
    routineDone = routine.active().negate();
  }

  protected static Trigger multiPathTrigger(
      Function<AutoTrajectory, Trigger> function, AutoTrajectory... paths) {
    if (paths.length == 0) {
      return new Trigger(() -> false);
    }

    Trigger trigger = function.apply(paths[0]);
    for (int i = 1; i < paths.length; i++) {
      trigger = trigger.or(function.apply(paths[i]));
    }

    return trigger;
  }

  protected static Trigger multiAtTime(String eventName, AutoTrajectory... paths) {
    return multiPathTrigger((path) -> path.atTime(eventName), paths);
  }

  protected static Trigger multiAtPose(
      String eventName, double toleranceMeters, double toleranceRadians, AutoTrajectory... paths) {
    return multiPathTrigger(
        (path) -> path.atPose(eventName, toleranceMeters, toleranceRadians), paths);
  }

  protected static Trigger multiActive(AutoTrajectory... paths) {
    return multiPathTrigger((path) -> path.active(), paths);
  }

  protected AutoTrajectory loadPath(ChoreoTraj path) {
    AutoTrajectory trajectory = path.asAutoTraj(routine);
    return inputs.mirrorAuto() ? trajectory.mirrorY() : trajectory;
  }

  protected Command lineUpAtEnd(Pose2d targetPose) {
    return AutoDriveCommands.driveToPose(s.drive(), targetPose);
  }

  private boolean withinTolerance(Rotation2d lhs, Rotation2d rhs, double toleranceRadians) {
    if (Math.abs(toleranceRadians) > Math.PI) {
      return true;
    }
    double dot = lhs.getCos() * rhs.getCos() + lhs.getSin() * rhs.getSin();
    // cos(θ) >= cos(tolerance) means |θ| <= tolerance, for tolerance in [-pi, pi], as pre-checked
    // above.
    return dot > Math.cos(toleranceRadians);
  }

  protected Trigger atPose(Pose2d pose) {
    return new Trigger(
        () -> {
          Pose2d currentPose = s.drive().getPose();
          boolean translationValid =
              currentPose.getTranslation().getDistance(pose.getTranslation())
                  < chainToleranceMeters;

          boolean rotationValid =
              withinTolerance(currentPose.getRotation(), pose.getRotation(), chainToleranceRadians);

          return translationValid && rotationValid;
        });
  }
}
